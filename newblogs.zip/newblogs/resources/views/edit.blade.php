<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <!DOCTYPE html>
    <html>

    <body>
        <form action="/edit" method="post">
            @csrf
            <input type="hidden" name="id" value="{{$data['id']}}">
            <label for="name"><b>Name</b></label>
            <input type="text" placeholder="Enter Name" name="name" id="name" value="{{$data['name']}}">
            <label for="email"><b>Email</b></label>
            <input type="text" placeholder="Enter Email" name="email" id="email" value="{{$data['email']}}">
            <label for="phonenumber"><b>Phone number</b></label>
            <input type="text" placeholder="Enter Phone number" name="phonenumber" id="phonenumber" value="{{$data['phone_number']}}">
            <input type="submit" value="Submit">
        </form>
    </body>

    </html>