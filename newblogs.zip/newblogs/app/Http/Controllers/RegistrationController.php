<?php

namespace App\Http\Controllers;

use  App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class RegistrationController extends Controller
{
    //
    public function index()
    {
        return view("registration");
    }
    public function registerUser(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:customers,email',
            'phonenumber' => 'required|digits:10|numeric',
            'psw' => 'required|min:7|max:12',
            'gender' => 'required'
        ], [
            'psw.required' => 'password is required'
        ]);
        $user = new Customer();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone_number = $request->phonenumber;
        $user->password = Hash::make($request->psw);
        $user->gender = $request->gender;
        $res = $user->save();
        if ($res) {
            return back()->with('success', 'You have registered successfully');
        } else {
            return back()->with('fail', 'something went wrong');
        }
    }
}
