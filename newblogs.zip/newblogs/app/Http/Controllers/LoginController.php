<?php

namespace App\Http\Controllers;

use  App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    //
    //<---------------------Function for getting login view page--------------->
    public function index()
    {
        return view('index');
    }


    //<-----------------Function for validating input credentials and user authentication--------------->
    public function check(Request $request)
    {

        $validatedData = $request->validate([
            'email' => 'required | string',
            'password' => 'required | string | min:7|max:12',

        ]);
        $user = Customer::whereEmail($request->email)->first();
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                $request->session()->put('LoggedUserData', [
                    'id' => $user->id,

                ]);
                return redirect()->route('dashboard');
            } else {
                return back()->with('fail', 'Sorry!!!Your have entered an incorrect Password');
            }
        } else {
            return back()->with('fail', 'No account found for this requested username!!!!');
        }
    }
}
