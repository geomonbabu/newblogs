<?php

namespace App\Http\Controllers;

use  App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;


class UserController extends Controller
{
    //
    // public function index()
    // {
    //     return view('dashboard');
    // }
    public function getAllUsers()
    {
        $member = Customer::all();
        // dd($member);
        return view('dashboard')->with('member', $member);
    }
    public function deleteData($id)
    {
        $data = Customer::find($id);
        $data->delete();
        return redirect('dashboard');
    }
    public function showData($id)
    {
        $data = Customer::find($id);
        return view('edit', ['data' => $data]);
    }
    public function updateData(Request $req)
    {
        $data = Customer::find($req->id);
        $data->name = $req->name;
        $data->email = $req->email;
        $data->phone_number = $req->phonenumber;
        $data->save();
        return redirect('dashboard')->with('success', 'Updated successfully');
    }
}
