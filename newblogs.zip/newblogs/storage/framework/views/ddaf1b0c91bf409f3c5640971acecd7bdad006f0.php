<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <!DOCTYPE html>
    <html>

    <body>
        <form action="/edit" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
            <label for="name"><b>Name</b></label>
            <input type="text" placeholder="Enter Name" name="name" id="name" value="<?php echo e($data['name']); ?>">
            <label for="email"><b>Email</b></label>
            <input type="text" placeholder="Enter Email" name="email" id="email" value="<?php echo e($data['email']); ?>">
            <label for="phonenumber"><b>Phone number</b></label>
            <input type="text" placeholder="Enter Phone number" name="phonenumber" id="phonenumber" value="<?php echo e($data['phone_number']); ?>">
            <input type="submit" value="Submit">
        </form>
    </body>

    </html><?php /**PATH C:\xampp\htdocs\newblogs\resources\views/edit.blade.php ENDPATH**/ ?>