<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=welcome, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    table,
    th,
    td {
        border: 1px solid black;
    }
</style>

<body>
    <table style="width:100%">
        <tr>
            <th>
                Name
            </th>
            <th>
                Action
            </th>
        </tr>
        <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->name); ?></td>

            <td><a href=<?php echo e("delete/".$data['id']); ?>>delete</a>
                <a href=<?php echo e("edit/".$data['id']); ?>>edit</a>
            </td>

        </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </table>
    <a href="/login">clickhere to go back</a>
</body>

</html><?php /**PATH C:\xampp\htdocs\newblogs\resources\views/dashboard.blade.php ENDPATH**/ ?>